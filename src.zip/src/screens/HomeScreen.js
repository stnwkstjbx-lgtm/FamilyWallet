import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, StatusBar, ActivityIndicator,
  TouchableOpacity, Alert, Modal, TextInput, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../constants/ThemeContext';
import { useAuth } from '../constants/AuthContext';
import { useWallet } from '../constants/WalletContext';
import { ALL_CATEGORY_NAMES, ALL_CATEGORY_ICONS, EXPENSE_CATEGORIES } from '../constants/categories';
import { db } from '../firebase/firebaseConfig';
import {
  collection, onSnapshot, orderBy, query, deleteDoc, doc, getDocs, updateDoc, addDoc,
} from 'firebase/firestore';

const showAlert = (title, message, buttons) => {
  if (Platform.OS === 'web') {
    if (buttons) {
      const confirmed = window.confirm(`${title}\n\n${message}`);
      if (confirmed && buttons[1]) buttons[1].onPress();
    } else { window.alert(`${title}\n\n${message}`); }
  } else { Alert.alert(title, message, buttons); }
};

export default function HomeScreen() {
  const { colors: Colors, isDark } = useTheme();
  const { user, userProfile } = useAuth();
  const { currentWalletId, currentWallet, isAdmin } = useWallet();
  const styles = getStyles(Colors);

  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [editAmount, setEditAmount] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editMemo, setEditMemo] = useState('');
  const [editType, setEditType] = useState('expense');
  const [editFundType, setEditFundType] = useState('shared');
  const [showSavingDetail, setShowSavingDetail] = useState(false);
  const autoRecordDone = useRef(false);

  useEffect(() => {
    if (!currentWalletId) { setLoading(false); return; }
    const q = query(collection(db, 'wallets', currentWalletId, 'transactions'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setTransactions(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsub();
  }, [currentWalletId]);

  // 고정 지출 자동 기록
  useEffect(() => {
    if (!isAdmin || !currentWalletId || autoRecordDone.current) return;
    autoRecordDone.current = true;
    const autoRecord = async () => {
      try {
        const now = new Date();
        const today = now.getDate();
        const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
        const fixedSnapshot = await getDocs(collection(db, 'wallets', currentWalletId, 'fixedExpenses'));
        let count = 0;
        for (const fixedDoc of fixedSnapshot.docs) {
          const data = fixedDoc.data();
          if (data.lastRecordedMonth === currentMonth) continue;
          const effectiveDay = Math.min(data.day || 1, lastDay);
          if (today >= effectiveDay) {
            await addDoc(collection(db, 'wallets', currentWalletId, 'transactions'), {
              type: 'expense', amount: data.amount, category: 'housing',
              memo: `[자동] ${data.name}`, member: '자동 기록', userId: 'system',
              fundType: 'shared',
              date: new Date(now.getFullYear(), now.getMonth(), effectiveDay).toISOString(),
              createdAt: new Date().toISOString(), fixedExpenseId: fixedDoc.id,
            });
            await updateDoc(doc(db, 'wallets', currentWalletId, 'fixedExpenses', fixedDoc.id), { lastRecordedMonth: currentMonth });
            count++;
          }
        }
        if (count > 0) showAlert('자동 기록 📋', `고정 지출 ${count}건 자동 기록 완료!`);
      } catch (error) { console.error('자동 기록 오류:', error); }
    };
    autoRecord();
  }, [isAdmin, currentWalletId]);

  const handleEdit = (item) => {
    setEditingItem(item); setEditAmount(String(item.amount));
    setEditCategory(item.category); setEditMemo(item.memo || '');
    setEditType(item.type); setEditFundType(item.fundType || 'shared');
    setShowEditModal(true);
  };
  const handleSaveEdit = async () => {
    if (!editAmount || editAmount === '0') { showAlert('알림', '금액을 입력해 주세요!'); return; }
    try {
      const updateData = { amount: parseInt(editAmount), category: editCategory, memo: editMemo, type: editType };
      if (editType === 'expense') updateData.fundType = editFundType;
      await updateDoc(doc(db, 'wallets', currentWalletId, 'transactions', editingItem.id), updateData);
      setShowEditModal(false); showAlert('수정 완료! ✅', '내역이 수정되었습니다.');
    } catch (error) { showAlert('오류', '수정에 실패했습니다.'); }
  };
  const handleDelete = (id, title) => {
    showAlert('삭제 확인', `"${title}" 삭제?`, [
      { text: '취소' },
      { text: '삭제', onPress: () => deleteDoc(doc(db, 'wallets', currentWalletId, 'transactions', id)) },
    ]);
  };

  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();

  const monthlyTx = transactions.filter((t) => {
    const d = new Date(t.date); return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  });

  const totalIncome = monthlyTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = monthlyTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const sharedExpense = monthlyTx.filter((t) => t.type === 'expense' && (t.fundType || 'shared') === 'shared').reduce((s, t) => s + t.amount, 0);
  const personalExpenseAll = monthlyTx.filter((t) => t.type === 'expense' && t.fundType === 'personal').reduce((s, t) => s + t.amount, 0);
  const balance = totalIncome - totalExpense;

  // ★★★ 용돈은 '개인 지출'만 집계! ★★★
  const myPersonalExpense = monthlyTx.filter((t) => t.type === 'expense' && t.fundType === 'personal' && t.userId === user?.uid).reduce((s, t) => s + t.amount, 0);
  const myAllowance = currentWallet?.members?.[user?.uid]?.allowance || 0;
  const myAllowanceRemain = myAllowance - myPersonalExpense;
  const myAllowancePct = myAllowance > 0 ? Math.min(Math.round((myPersonalExpense / myAllowance) * 100), 100) : 0;

  // 저축 분석
  const monthlyData = {};
  transactions.forEach((t) => {
    const d = new Date(t.date);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    if (!monthlyData[key]) monthlyData[key] = { income: 0, expense: 0 };
    if (t.type === 'income') monthlyData[key].income += t.amount;
    else monthlyData[key].expense += t.amount;
  });

  const monthKeys = Object.keys(monthlyData).sort();
  const monthlySavings = monthKeys.map((k) => ({ month: k, saving: Math.max(monthlyData[k].income - monthlyData[k].expense, 0), income: monthlyData[k].income, expense: monthlyData[k].expense }));
  const totalSavingSum = monthlySavings.reduce((s, m) => s + m.saving, 0);
  const avgMonthlySaving = monthKeys.length > 0 ? Math.round(totalSavingSum / monthKeys.length) : (balance > 0 ? balance : 0);
  const bestMonth = monthlySavings.length > 0 ? monthlySavings.reduce((best, m) => m.saving > best.saving ? m : best, monthlySavings[0]) : null;
  const currentMonthSaving = balance > 0 ? balance : 0;
  const savingTrend = avgMonthlySaving > 0 ? Math.round(((currentMonthSaving - avgMonthlySaving) / avgMonthlySaving) * 100) : 0;
  const projections = [1, 2, 3, 5, 10].map((y) => ({ year: y, amount: avgMonthlySaving * 12 * y }));

  const formatMoney = (num) => Math.abs(num).toLocaleString('ko-KR') + '원';
  const formatBigMoney = (num) => {
    if (num >= 100000000) return (num / 100000000).toFixed(1) + '억원';
    if (num >= 10000) return Math.round(num / 10000).toLocaleString('ko-KR') + '만원';
    return num.toLocaleString('ko-KR') + '원';
  };
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const diff = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    if (diff === 0) return '오늘';
    if (diff === 1) return '어제';
    if (diff < 7) return `${diff}일 전`;
    return `${date.getMonth() + 1}/${date.getDate()}`;
  };
  const formatTime = (dateString) => {
    const date = new Date(dateString);
    const h = date.getHours();
    const m = String(date.getMinutes()).padStart(2, '0');
    return `${h < 12 ? '오전' : '오후'} ${h % 12 || 12}:${m}`;
  };

  const myWalletName = currentWallet?.members?.[user?.uid]?.name || userProfile?.name || '';

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={{ marginTop: 10, color: Colors.textGray }}>데이터를 불러오는 중...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <ScrollView showsVerticalScrollIndicator={false}>

        <LinearGradient colors={[Colors.gradientStart, Colors.gradientMiddle, Colors.gradientEnd]} style={styles.headerGradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.appTitle}>📒 {currentWallet?.name || '가계부'}</Text>
              <Text style={styles.welcomeText}>{myWalletName}님, 안녕하세요! 👋</Text>
            </View>
            <View style={styles.headerBadge}>
              <Ionicons name={isDark ? 'moon' : 'sunny'} size={16} color="#FFFFFF" />
            </View>
          </View>

          {/* 잔액 카드 */}
          <View style={styles.balanceCard}>
            <View style={styles.balanceLabelRow}>
              <Text style={styles.balanceLabel}>이번 달 가족 잔액</Text>
              <View style={styles.monthBadge}><Text style={styles.monthBadgeText}>{now.getMonth() + 1}월</Text></View>
            </View>
            <Text style={[styles.balanceAmount, { color: balance >= 0 ? Colors.textBlack : Colors.expense }]}>
              {balance < 0 ? '-' : ''}{formatMoney(balance)}
            </Text>

            <View style={styles.ieRow}>
              <View style={styles.ieBox}>
                <View style={[styles.ieIconBox, { backgroundColor: Colors.income + '15' }]}>
                  <Ionicons name="arrow-down-circle" size={18} color={Colors.income} />
                </View>
                <View>
                  <Text style={styles.ieLabel}>수입</Text>
                  <Text style={[styles.ieAmount, { color: Colors.income }]}>{formatMoney(totalIncome)}</Text>
                </View>
              </View>
              <View style={styles.ieDivider} />
              <View style={styles.ieBox}>
                <View style={[styles.ieIconBox, { backgroundColor: Colors.expense + '15' }]}>
                  <Ionicons name="arrow-up-circle" size={18} color={Colors.expense} />
                </View>
                <View>
                  <Text style={styles.ieLabel}>지출</Text>
                  <Text style={[styles.ieAmount, { color: Colors.expense }]}>{formatMoney(totalExpense)}</Text>
                </View>
              </View>
            </View>

            {/* 공금 / 용돈 지출 분리 표시 */}
            {totalExpense > 0 && (
              <View style={styles.fundSplitRow}>
                <View style={styles.fundSplitItem}>
                  <Ionicons name="people" size={13} color={Colors.primary} />
                  <Text style={styles.fundSplitLabel}>공금</Text>
                  <Text style={styles.fundSplitValue}>{formatMoney(sharedExpense)}</Text>
                </View>
                <View style={styles.fundSplitDot} />
                <View style={styles.fundSplitItem}>
                  <Ionicons name="person" size={13} color={Colors.income} />
                  <Text style={styles.fundSplitLabel}>용돈</Text>
                  <Text style={styles.fundSplitValue}>{formatMoney(personalExpenseAll)}</Text>
                </View>
              </View>
            )}

            {/* 내 용돈 (개인 지출만!) */}
            {myAllowance > 0 && (
              <View style={styles.allowanceSection}>
                <View style={styles.allowanceHeader}>
                  <View style={styles.allowanceIconBox}>
                    <Text style={{ fontSize: 14 }}>💰</Text>
                  </View>
                  <Text style={styles.allowanceTitle}>내 용돈</Text>
                  <Text style={[styles.allowanceRemain, { color: myAllowanceRemain >= 0 ? Colors.income : Colors.expense }]}>
                    {myAllowanceRemain >= 0 ? '' : '-'}{formatMoney(myAllowanceRemain)}{myAllowanceRemain < 0 ? ' 초과' : ' 남음'}
                  </Text>
                </View>
                <View style={styles.allowanceDetail}>
                  <Text style={styles.allowanceDetailText}>한도 {formatMoney(myAllowance)}</Text>
                  <Text style={styles.allowanceDetailText}>사용 {formatMoney(myPersonalExpense)}</Text>
                </View>
                <View style={styles.barBg}>
                  <View style={[styles.barFill, {
                    width: `${myAllowancePct}%`,
                    backgroundColor: myAllowancePct >= 90 ? Colors.expense : myAllowancePct >= 70 ? Colors.warning : Colors.income,
                  }]} />
                </View>
                <Text style={styles.barPct}>{myAllowancePct}% 사용 · 개인 지출만 집계</Text>
              </View>
            )}
          </View>
        </LinearGradient>

        {/* 저축 리포트 */}
        {(avgMonthlySaving > 0 || currentMonthSaving > 0) && (
          <View style={styles.section}>
            <TouchableOpacity style={styles.savingCard} onPress={() => setShowSavingDetail(true)} activeOpacity={0.85}>
              <View style={styles.savingHeader}>
                <View style={styles.savingIconBox}><Ionicons name="trending-up" size={22} color={Colors.income} /></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.savingTitle}>💪 저축 리포트</Text>
                  <Text style={styles.savingSubTitle}>탭하면 상세 분석 →</Text>
                </View>
              </View>

              <View style={styles.savingMainRow}>
                <View style={styles.savingMainItem}>
                  <Text style={styles.savingMainLabel}>이번 달</Text>
                  <Text style={[styles.savingMainValue, { color: currentMonthSaving > 0 ? Colors.income : Colors.expense }]}>{formatBigMoney(currentMonthSaving)}</Text>
                </View>
                <View style={styles.savingMainDivider} />
                <View style={styles.savingMainItem}>
                  <Text style={styles.savingMainLabel}>월 평균</Text>
                  <Text style={[styles.savingMainValue, { color: Colors.primary }]}>{formatBigMoney(avgMonthlySaving)}</Text>
                </View>
              </View>

              {monthKeys.length > 1 && (
                <View style={[styles.trendBadge, { backgroundColor: savingTrend >= 0 ? Colors.income + '15' : Colors.expense + '15' }]}>
                  <Ionicons name={savingTrend >= 0 ? 'arrow-up' : 'arrow-down'} size={13} color={savingTrend >= 0 ? Colors.income : Colors.expense} />
                  <Text style={[styles.trendText, { color: savingTrend >= 0 ? Colors.income : Colors.expense }]}>평균 대비 {Math.abs(savingTrend)}% {savingTrend >= 0 ? '더 저축' : '덜 저축'}</Text>
                </View>
              )}

              <View style={styles.projectionBox}>
                <Text style={styles.projectionText}>이대로면 <Text style={styles.projectionBold}>5년 뒤 {formatBigMoney(avgMonthlySaving * 60)}</Text> 모여요! 🎉</Text>
              </View>

              <View style={styles.miniBarRow}>
                {[1, 2, 3, 4, 5].map((y) => (
                  <View key={y} style={styles.miniBarItem}>
                    <View style={[styles.miniBar, { height: Math.max(6, (y / 5) * 36), backgroundColor: y === 5 ? Colors.income : Colors.income + '45' }]} />
                    <Text style={styles.miniBarLabel}>{y}년</Text>
                  </View>
                ))}
              </View>
            </TouchableOpacity>
          </View>
        )}

        {/* 가족 활동 */}
        {transactions.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>👨‍👩‍👧 가족 활동</Text>
            {transactions.slice(0, 3).map((item) => (
              <View key={item.id + '_feed'} style={styles.feedCard}>
                <View style={[styles.feedAvatar, { backgroundColor: (Colors.category[item.category] || Colors.primary) + '20' }]}>
                  <Ionicons name={ALL_CATEGORY_ICONS[item.category] || 'ellipsis-horizontal-outline'} size={16} color={Colors.category[item.category] || Colors.primary} />
                </View>
                <View style={styles.feedContent}>
                  <Text style={styles.feedText}>
                    <Text style={styles.feedMember}>{item.member || '미지정'}</Text>님이{' '}
                    <Text style={{ color: item.type === 'income' ? Colors.income : Colors.expense }}>{formatMoney(item.amount)}</Text>
                    {' '}{item.type === 'income' ? '수입' : '지출'}
                    {item.type === 'expense' && (
                      <Text style={{ color: Colors.textLight }}> ({(item.fundType || 'shared') === 'personal' ? '용돈' : '공금'})</Text>
                    )}
                  </Text>
                  <Text style={styles.feedTime}>{formatDate(item.date)} {formatTime(item.date)}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* 최근 내역 */}
        <View style={[styles.section, { paddingBottom: 100 }]}>
          <Text style={styles.sectionTitle}>최근 내역</Text>
          <Text style={styles.sectionSubtitle}>탭 → 수정 · 길게 → 삭제</Text>

          {transactions.length === 0 ? (
            <View style={styles.emptyCard}>
              <View style={styles.emptyIconBox}><Ionicons name="receipt-outline" size={36} color={Colors.textLight} /></View>
              <Text style={styles.emptyText}>아직 기록이 없어요</Text>
              <Text style={styles.emptySubText}>"추가" 탭에서 첫 내역을 기록해 보세요!</Text>
            </View>
          ) : (
            transactions.map((item) => {
              const isPersonal = item.type === 'expense' && item.fundType === 'personal';
              return (
                <TouchableOpacity key={item.id} style={styles.txCard} onPress={() => handleEdit(item)} onLongPress={() => handleDelete(item.id, item.memo || ALL_CATEGORY_NAMES[item.category] || '기타')} delayLongPress={500}>
                  <View style={[styles.txIcon, { backgroundColor: (Colors.category[item.category] || Colors.primary) + '15' }]}>
                    <Ionicons name={ALL_CATEGORY_ICONS[item.category] || 'ellipsis-horizontal-outline'} size={22} color={Colors.category[item.category] || Colors.primary} />
                  </View>
                  <View style={styles.txInfo}>
                    <View style={styles.txTitleRow}>
                      <Text style={styles.txTitle} numberOfLines={1}>{item.memo || ALL_CATEGORY_NAMES[item.category] || '기타'}</Text>
                      {item.type === 'expense' && (
                        <View style={[styles.fundTag, { backgroundColor: isPersonal ? Colors.income + '15' : Colors.primary + '12' }]}>
                          <Ionicons name={isPersonal ? 'person' : 'people'} size={10} color={isPersonal ? Colors.income : Colors.primary} />
                          <Text style={[styles.fundTagText, { color: isPersonal ? Colors.income : Colors.primary }]}>{isPersonal ? '용돈' : '공금'}</Text>
                        </View>
                      )}
                    </View>
                    <Text style={styles.txDate}>{item.member && item.member !== '미지정' ? item.member + ' · ' : ''}{formatDate(item.date)}</Text>
                  </View>
                  <Text style={[styles.txAmount, { color: item.type === 'income' ? Colors.income : Colors.expense }]}>
                    {item.type === 'income' ? '+' : '-'}{formatMoney(item.amount)}
                  </Text>
                </TouchableOpacity>
              );
            })
          )}
        </View>
      </ScrollView>

      {/* 저축 상세 모달 */}
      <Modal visible={showSavingDetail} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '90%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>📊 저축 상세 분석</Text>
              <TouchableOpacity onPress={() => setShowSavingDetail(false)}><Ionicons name="close-circle" size={28} color={Colors.textLight} /></TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.savingStatGrid}>
                <View style={[styles.savingStat, { backgroundColor: Colors.income + '12' }]}>
                  <Text style={styles.savingStatLabel}>월 평균 저축</Text>
                  <Text style={[styles.savingStatValue, { color: Colors.income }]}>{formatBigMoney(avgMonthlySaving)}</Text>
                </View>
                <View style={[styles.savingStat, { backgroundColor: Colors.primary + '12' }]}>
                  <Text style={styles.savingStatLabel}>총 누적 저축</Text>
                  <Text style={[styles.savingStatValue, { color: Colors.primary }]}>{formatBigMoney(totalSavingSum)}</Text>
                </View>
              </View>
              {bestMonth && monthKeys.length > 1 && (
                <View style={[styles.savingStat, { backgroundColor: Colors.warning + '12', marginBottom: 20 }]}>
                  <Text style={styles.savingStatLabel}>🏆 최고 저축 달</Text>
                  <Text style={[styles.savingStatValue, { color: Colors.warning }]}>{bestMonth.month} — {formatBigMoney(bestMonth.saving)}</Text>
                </View>
              )}
              <Text style={styles.detailSectionTitle}>🔮 미래 예측</Text>
              {projections.map((p) => (
                <View key={p.year} style={styles.projRow}>
                  <View style={styles.projYearBadge}><Text style={styles.projYearText}>{p.year}년</Text></View>
                  <View style={styles.projBarBg}><View style={[styles.projBarFill, { width: `${Math.min((p.amount / (projections[4].amount || 1)) * 100, 100)}%` }]} /></View>
                  <Text style={styles.projAmount}>{formatBigMoney(p.amount)}</Text>
                </View>
              ))}
              {monthlySavings.length > 1 && (
                <>
                  <Text style={[styles.detailSectionTitle, { marginTop: 24 }]}>📅 월별 저축</Text>
                  {monthlySavings.slice().reverse().map((m) => {
                    const pct = avgMonthlySaving > 0 ? Math.round((m.saving / avgMonthlySaving) * 100) : 0;
                    return (
                      <View key={m.month} style={styles.monthRow}>
                        <Text style={styles.monthLabel}>{m.month}</Text>
                        <View style={styles.monthBarBg}><View style={[styles.monthBarFill, { width: `${Math.min(pct, 150)}%`, backgroundColor: m.saving >= avgMonthlySaving ? Colors.income : Colors.warning }]} /></View>
                        <Text style={[styles.monthAmount, { color: m.saving >= avgMonthlySaving ? Colors.income : Colors.textGray }]}>{formatBigMoney(m.saving)}</Text>
                      </View>
                    );
                  })}
                </>
              )}
              <View style={styles.cheerBox}>
                <Text style={styles.cheerEmoji}>{avgMonthlySaving >= 1000000 ? '🏆' : avgMonthlySaving >= 500000 ? '🔥' : avgMonthlySaving >= 100000 ? '💪' : '🌱'}</Text>
                <Text style={styles.cheerText}>
                  {avgMonthlySaving >= 1000000 ? '대단해요! 월 100만원 이상 저축 중!' : avgMonthlySaving >= 500000 ? '잘하고 있어요! 꾸준히 유지하면 큰 목돈이!' : avgMonthlySaving >= 100000 ? '좋은 습관! 조금씩 늘려보면 어떨까요?' : '시작이 반! 작은 저축도 큰 차이를 만들어요!'}
                </Text>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* 수정 모달 */}
      <Modal visible={showEditModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>내역 수정</Text>
              <TouchableOpacity onPress={() => setShowEditModal(false)}><Ionicons name="close-circle" size={28} color={Colors.textLight} /></TouchableOpacity>
            </View>
            <View style={styles.editTypeRow}>
              <TouchableOpacity style={[styles.editTypeBtn, editType === 'expense' && { backgroundColor: Colors.expense }]} onPress={() => setEditType('expense')}>
                <Text style={[styles.editTypeBtnText, editType === 'expense' && { color: '#FFF' }]}>지출</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.editTypeBtn, editType === 'income' && { backgroundColor: Colors.income }]} onPress={() => setEditType('income')}>
                <Text style={[styles.editTypeBtnText, editType === 'income' && { color: '#FFF' }]}>수입</Text>
              </TouchableOpacity>
            </View>
            {editType === 'expense' && (
              <View style={styles.editFundRow}>
                <TouchableOpacity style={[styles.editFundBtn, editFundType === 'shared' && { backgroundColor: Colors.primary + '20', borderColor: Colors.primary }]} onPress={() => setEditFundType('shared')}>
                  <Ionicons name="people" size={14} color={Colors.primary} /><Text style={[styles.editFundText, { color: Colors.primary }]}>공금</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.editFundBtn, editFundType === 'personal' && { backgroundColor: Colors.income + '20', borderColor: Colors.income }]} onPress={() => setEditFundType('personal')}>
                  <Ionicons name="person" size={14} color={Colors.income} /><Text style={[styles.editFundText, { color: Colors.income }]}>용돈</Text>
                </TouchableOpacity>
              </View>
            )}
            <Text style={styles.editLabel}>금액</Text>
            <TextInput style={styles.editInput} keyboardType="numeric" value={editAmount} onChangeText={(t) => setEditAmount(t.replace(/[^0-9]/g, ''))} />
            {editAmount ? <Text style={styles.editPreview}>{parseInt(editAmount).toLocaleString('ko-KR')}원</Text> : null}
            <Text style={styles.editLabel}>카테고리</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 4 }}>
              {EXPENSE_CATEGORIES.map((cat) => (
                <TouchableOpacity key={cat.id} style={[styles.editCatChip, editCategory === cat.id && { backgroundColor: Colors.category[cat.id], borderColor: Colors.category[cat.id] }]} onPress={() => setEditCategory(cat.id)}>
                  <Ionicons name={cat.icon} size={14} color={editCategory === cat.id ? '#FFF' : Colors.category[cat.id]} />
                  <Text style={[styles.editCatText, editCategory === cat.id && { color: '#FFF' }]}>{cat.name}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <Text style={styles.editLabel}>메모</Text>
            <TextInput style={styles.editInput} placeholder="메모" placeholderTextColor={Colors.textLight} value={editMemo} onChangeText={setEditMemo} />
            <View style={styles.editBtns}>
              <TouchableOpacity style={styles.editCancelBtn} onPress={() => setShowEditModal(false)}><Text style={styles.editCancelText}>취소</Text></TouchableOpacity>
              <TouchableOpacity style={styles.editSaveBtn} onPress={handleSaveEdit}><Text style={styles.editSaveText}>수정 완료</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const getStyles = (Colors) => StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  headerGradient: { paddingTop: 60, paddingBottom: 30, paddingHorizontal: 20, borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 25 },
  appTitle: { fontSize: 24, fontWeight: '800', color: '#FFFFFF', letterSpacing: -0.5 },
  welcomeText: { fontSize: 13, color: 'rgba(255,255,255,0.8)', marginTop: 4 },
  headerBadge: { width: 36, height: 36, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.15)', justifyContent: 'center', alignItems: 'center' },
  // 잔액 카드
  balanceCard: { backgroundColor: Colors.surface, borderRadius: 22, padding: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.08, shadowRadius: 16, elevation: 6 },
  balanceLabelRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  balanceLabel: { fontSize: 14, color: Colors.textGray },
  monthBadge: { backgroundColor: Colors.primary + '15', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  monthBadgeText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
  balanceAmount: { fontSize: 34, fontWeight: '800', letterSpacing: -1, marginTop: 4, marginBottom: 22 },
  ieRow: { flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' },
  ieBox: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  ieIconBox: { width: 36, height: 36, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  ieLabel: { fontSize: 12, color: Colors.textGray },
  ieAmount: { fontSize: 16, fontWeight: '700' },
  ieDivider: { width: 1, height: 36, backgroundColor: Colors.textLight + '30' },
  // 공금/용돈 분리
  fundSplitRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 16, marginTop: 16, paddingTop: 14, borderTopWidth: 1, borderTopColor: Colors.background },
  fundSplitItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  fundSplitLabel: { fontSize: 12, color: Colors.textGray },
  fundSplitValue: { fontSize: 13, fontWeight: '600', color: Colors.textDark },
  fundSplitDot: { width: 3, height: 3, borderRadius: 2, backgroundColor: Colors.textLight },
  // 용돈
  allowanceSection: { marginTop: 16, backgroundColor: Colors.background, borderRadius: 14, padding: 16 },
  allowanceHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  allowanceIconBox: { marginRight: 4 },
  allowanceTitle: { fontSize: 14, fontWeight: '700', color: Colors.textBlack, flex: 1 },
  allowanceRemain: { fontSize: 16, fontWeight: '800' },
  allowanceDetail: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  allowanceDetailText: { fontSize: 12, color: Colors.textGray },
  barBg: { height: 6, backgroundColor: Colors.surface, borderRadius: 3 },
  barFill: { height: 6, borderRadius: 3 },
  barPct: { fontSize: 11, color: Colors.textLight, textAlign: 'right', marginTop: 4 },
  // 저축
  savingCard: { backgroundColor: Colors.surface, borderRadius: 20, padding: 20, borderWidth: 1, borderColor: Colors.income + '20', shadowColor: Colors.income, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 10, elevation: 2 },
  savingHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  savingIconBox: { width: 42, height: 42, borderRadius: 13, backgroundColor: Colors.income + '12', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  savingTitle: { fontSize: 17, fontWeight: '800', color: Colors.textBlack },
  savingSubTitle: { fontSize: 12, color: Colors.textLight, marginTop: 2 },
  savingMainRow: { flexDirection: 'row', backgroundColor: Colors.background, borderRadius: 14, padding: 16, marginBottom: 12 },
  savingMainItem: { flex: 1, alignItems: 'center' },
  savingMainLabel: { fontSize: 12, color: Colors.textGray, marginBottom: 4 },
  savingMainValue: { fontSize: 18, fontWeight: '800' },
  savingMainDivider: { width: 1, backgroundColor: Colors.textLight + '30' },
  trendBadge: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, borderRadius: 10, paddingVertical: 8, marginBottom: 12 },
  trendText: { fontSize: 13, fontWeight: '600' },
  projectionBox: { backgroundColor: Colors.primary + '08', borderRadius: 12, padding: 14, marginBottom: 12 },
  projectionText: { fontSize: 14, color: Colors.textDark, textAlign: 'center', lineHeight: 22 },
  projectionBold: { fontWeight: '800', color: Colors.primary },
  miniBarRow: { flexDirection: 'row', justifyContent: 'space-around', alignItems: 'flex-end', height: 48 },
  miniBarItem: { alignItems: 'center' },
  miniBar: { width: 22, borderRadius: 6 },
  miniBarLabel: { fontSize: 10, color: Colors.textGray, marginTop: 4 },
  // 피드
  feedCard: { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: Colors.surface, borderRadius: 14, padding: 14, marginBottom: 8, gap: 12, borderWidth: 1, borderColor: Colors.background },
  feedAvatar: { width: 34, height: 34, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  feedContent: { flex: 1 },
  feedText: { fontSize: 14, color: Colors.textDark, lineHeight: 20 },
  feedMember: { fontWeight: '700', color: Colors.primary },
  feedTime: { fontSize: 11, color: Colors.textLight, marginTop: 4 },
  // 내역
  txCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, borderRadius: 16, padding: 16, marginBottom: 10, gap: 12, borderWidth: 1, borderColor: Colors.background },
  txIcon: { width: 44, height: 44, borderRadius: 13, justifyContent: 'center', alignItems: 'center' },
  txInfo: { flex: 1 },
  txTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  txTitle: { fontSize: 15, fontWeight: '600', color: Colors.textBlack, flexShrink: 1 },
  fundTag: { flexDirection: 'row', alignItems: 'center', gap: 2, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  fundTagText: { fontSize: 10, fontWeight: '700' },
  txDate: { fontSize: 12, color: Colors.textGray, marginTop: 3 },
  txAmount: { fontSize: 16, fontWeight: '800' },
  // 빈 상태
  emptyCard: { alignItems: 'center', paddingVertical: 40, backgroundColor: Colors.surface, borderRadius: 18, borderWidth: 1, borderColor: Colors.background },
  emptyIconBox: { width: 64, height: 64, borderRadius: 20, backgroundColor: Colors.background, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  emptyText: { fontSize: 16, fontWeight: '700', color: Colors.textGray },
  emptySubText: { fontSize: 13, color: Colors.textLight, marginTop: 4 },
  // 섹션
  section: { paddingHorizontal: 20, paddingTop: 24 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: Colors.textBlack, marginBottom: 4, letterSpacing: -0.3 },
  sectionSubtitle: { fontSize: 12, color: Colors.textLight, marginBottom: 14 },
  // 모달
  modalOverlay: { flex: 1, backgroundColor: Colors.modalOverlay, justifyContent: 'flex-end' },
  modalContent: { backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 40, maxHeight: '85%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: '800', color: Colors.textBlack },
  // 수정 모달
  editTypeRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  editTypeBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: 'center', backgroundColor: Colors.background },
  editTypeBtnText: { fontSize: 15, fontWeight: '700', color: Colors.textGray },
  editFundRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  editFundBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, borderColor: Colors.background, backgroundColor: Colors.background },
  editFundText: { fontSize: 13, fontWeight: '700' },
  editLabel: { fontSize: 13, fontWeight: '700', color: Colors.textGray, marginBottom: 8, marginTop: 12 },
  editInput: { backgroundColor: Colors.background, borderRadius: 12, padding: 14, fontSize: 16, color: Colors.textBlack },
  editPreview: { fontSize: 13, color: Colors.primary, marginTop: 4 },
  editCatChip: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, marginRight: 8, backgroundColor: Colors.background, borderWidth: 1.5, borderColor: Colors.background },
  editCatText: { fontSize: 13, fontWeight: '600', color: Colors.textDark },
  editBtns: { flexDirection: 'row', gap: 12, marginTop: 24 },
  editCancelBtn: { flex: 1, backgroundColor: Colors.background, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  editCancelText: { fontSize: 15, fontWeight: '600', color: Colors.textGray },
  editSaveBtn: { flex: 1, backgroundColor: Colors.primary, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  editSaveText: { fontSize: 15, fontWeight: '800', color: '#FFF' },
  // 상세 모달
  savingStatGrid: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  savingStat: { flex: 1, borderRadius: 14, padding: 16, alignItems: 'center' },
  savingStatLabel: { fontSize: 12, color: Colors.textGray, marginBottom: 4 },
  savingStatValue: { fontSize: 18, fontWeight: '800' },
  detailSectionTitle: { fontSize: 16, fontWeight: '800', color: Colors.textBlack, marginBottom: 12 },
  projRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, gap: 10 },
  projYearBadge: { backgroundColor: Colors.primary + '15', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5, width: 50, alignItems: 'center' },
  projYearText: { fontSize: 12, fontWeight: '700', color: Colors.primary },
  projBarBg: { flex: 1, height: 8, backgroundColor: Colors.background, borderRadius: 4 },
  projBarFill: { height: 8, borderRadius: 4, backgroundColor: Colors.income },
  projAmount: { fontSize: 13, fontWeight: '600', color: Colors.textBlack, width: 80, textAlign: 'right' },
  monthRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 8 },
  monthLabel: { fontSize: 12, color: Colors.textGray, width: 60 },
  monthBarBg: { flex: 1, height: 8, backgroundColor: Colors.background, borderRadius: 4 },
  monthBarFill: { height: 8, borderRadius: 4 },
  monthAmount: { fontSize: 12, fontWeight: '600', width: 70, textAlign: 'right' },
  cheerBox: { backgroundColor: Colors.income + '08', borderRadius: 16, padding: 20, alignItems: 'center', marginTop: 20, marginBottom: 20 },
  cheerEmoji: { fontSize: 36, marginBottom: 8 },
  cheerText: { fontSize: 14, color: Colors.textDark, textAlign: 'center', lineHeight: 22 },
});