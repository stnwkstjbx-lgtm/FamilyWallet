/**
 * AllowanceScreen.js
 * ─────────────────────────────────────────────
 * 개인 용돈 관리 화면
 *   - 이번 달 용돈 배분액 / 사용액 / 잔액
 *   - 저번 달 잔액
 *   - 3개월 평균 잔액
 *   - 1년 예상 저축
 *   - 이번 달 용돈 사용 내역 리스트
 *   - 용돈 사용 추가 버튼
 *
 *  ★ 본인의 용돈 데이터만 표시됨 (다른 가족은 볼 수 없음)
 * ─────────────────────────────────────────────
 */

import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Platform,
  Alert,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useWallet } from '../constants/WalletContext';
import { useTheme } from '../constants/ThemeContext';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// ───── 카테고리 목록 ─────
const PERSONAL_CATEGORIES = [
  { key: '식비', icon: 'fast-food-outline', color: '#FF6B6B' },
  { key: '카페', icon: 'cafe-outline', color: '#D4A574' },
  { key: '교통', icon: 'bus-outline', color: '#4ECDC4' },
  { key: '쇼핑', icon: 'cart-outline', color: '#FFD93D' },
  { key: '취미', icon: 'game-controller-outline', color: '#6C63FF' },
  { key: '문화', icon: 'film-outline', color: '#FF8E8E' },
  { key: '건강', icon: 'fitness-outline', color: '#2ECC71' },
  { key: '기타', icon: 'ellipsis-horizontal-outline', color: '#95A5A6' },
];

export default function AllowanceScreen() {
  const { Colors } = useTheme();
  const { getAllowanceReport, addPersonalExpense } = useWallet();

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseDesc, setExpenseDesc] = useState('');

  // ───── 리포트 데이터 ─────
  const report = useMemo(() => getAllowanceReport(), [getAllowanceReport]);

  if (!report) {
    return (
      <View style={[styles.container, { backgroundColor: Colors.background }]}>
        <Text style={[styles.emptyText, { color: Colors.textSecondary }]}>
          용돈 데이터를 불러올 수 없어요
        </Text>
      </View>
    );
  }

  const {
    currentMonth,
    current,
    last,
    avg3MonthRemaining,
    projectedYearlySavings,
    currentMonthPersonalTxs,
  } = report;

  // 잔액 퍼센트
  const remainingPercent =
    current.allocation > 0
      ? Math.max(0, Math.min(100, Math.round((current.remaining / current.allocation) * 100)))
      : 0;

  // ───── 금액 포맷 ─────
  const formatMoney = (val) => {
    if (val == null) return '0원';
    const abs = Math.abs(val);
    if (abs >= 10000) {
      const man = Math.floor(abs / 10000);
      const rest = abs % 10000;
      return (val < 0 ? '-' : '') + (rest > 0 ? `${man}만 ${rest.toLocaleString()}원` : `${man}만원`);
    }
    return `${val.toLocaleString()}원`;
  };

  const formatMoneyShort = (val) => {
    if (val == null) return '0원';
    return `${val.toLocaleString()}원`;
  };

  // ───── 월 표시 ─────
  const formatMonth = (ym) => {
    if (!ym) return '';
    const [y, m] = ym.split('-');
    return `${y}년 ${parseInt(m)}월`;
  };

  // ───── 지출 추가 핸들러 ─────
  const handleAddExpense = async () => {
    if (!selectedCategory) {
      Alert.alert('알림', '카테고리를 선택해주세요');
      return;
    }
    const amount = parseInt(expenseAmount);
    if (!amount || amount <= 0) {
      Alert.alert('알림', '금액을 입력해주세요');
      return;
    }

    try {
      await addPersonalExpense({
        category: selectedCategory,
        amount,
        description: expenseDesc || selectedCategory,
        date: new Date().toISOString().slice(0, 10),
      });
      setShowAddModal(false);
      setSelectedCategory(null);
      setExpenseAmount('');
      setExpenseDesc('');
    } catch (e) {
      Alert.alert('오류', e.message);
    }
  };

  // ═══════════════════════════════════════
  // 렌더
  // ═══════════════════════════════════════

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: Colors.background }]}
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={false}
    >
      {/* ───── 헤더 ───── */}
      <LinearGradient
        colors={[Colors.gradientStart || '#667eea', Colors.gradientEnd || '#764ba2']}
        style={styles.header}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.headerDecor1} />
        <View style={styles.headerDecor2} />

        <Text style={styles.headerTitle}>내 용돈</Text>
        <Text style={styles.headerMonth}>{formatMonth(currentMonth)}</Text>

        {/* 잔액 원형 인디케이터 */}
        <View style={styles.circleContainer}>
          <View style={styles.circleOuter}>
            <View
              style={[
                styles.circleProgress,
                {
                  backgroundColor:
                    remainingPercent > 50 ? '#2ECC71' : remainingPercent > 20 ? '#FFD93D' : '#FF6B6B',
                },
              ]}
            />
            <View style={styles.circleInner}>
              <Text style={styles.circlePercent}>{remainingPercent}%</Text>
              <Text style={styles.circleLabel}>남음</Text>
            </View>
          </View>
        </View>

        {/* 배분 / 사용 / 잔액 */}
        <View style={styles.headerStats}>
          <View style={styles.headerStatItem}>
            <Text style={styles.headerStatLabel}>배분</Text>
            <Text style={styles.headerStatValue}>{formatMoneyShort(current.allocation)}</Text>
          </View>
          <View style={[styles.headerStatDivider]} />
          <View style={styles.headerStatItem}>
            <Text style={styles.headerStatLabel}>사용</Text>
            <Text style={[styles.headerStatValue, { color: '#FF8E8E' }]}>
              {formatMoneyShort(current.spending)}
            </Text>
          </View>
          <View style={[styles.headerStatDivider]} />
          <View style={styles.headerStatItem}>
            <Text style={styles.headerStatLabel}>잔액</Text>
            <Text
              style={[
                styles.headerStatValue,
                { color: current.remaining >= 0 ? '#A8F0C6' : '#FF8E8E' },
              ]}
            >
              {formatMoneyShort(current.remaining)}
            </Text>
          </View>
        </View>
      </LinearGradient>

      {/* ───── 용돈 저축 리포트 카드 ───── */}
      <View style={[styles.reportCard, { backgroundColor: Colors.surface }]}>
        <View style={styles.reportHeader}>
          <Ionicons name="trending-up" size={20} color="#2ECC71" />
          <Text style={[styles.reportTitle, { color: Colors.text }]}>용돈 저축 리포트</Text>
        </View>

        <View style={styles.reportGrid}>
          {/* 저번 달 잔액 */}
          <View style={[styles.reportItem, { backgroundColor: Colors.background }]}>
            <Ionicons name="calendar-outline" size={18} color="#6C63FF" />
            <Text style={[styles.reportItemLabel, { color: Colors.textSecondary }]}>
              저번 달 잔액
            </Text>
            <Text style={[styles.reportItemValue, { color: Colors.text }]}>
              {formatMoney(last.remaining)}
            </Text>
            {last.allocation > 0 && (
              <Text style={[styles.reportItemSub, { color: Colors.textSecondary }]}>
                {last.allocation > 0
                  ? `${Math.round((last.remaining / last.allocation) * 100)}% 절약`
                  : ''}
              </Text>
            )}
          </View>

          {/* 3개월 평균 잔액 */}
          <View style={[styles.reportItem, { backgroundColor: Colors.background }]}>
            <Ionicons name="stats-chart-outline" size={18} color="#4ECDC4" />
            <Text style={[styles.reportItemLabel, { color: Colors.textSecondary }]}>
              3개월 평균 잔액
            </Text>
            <Text style={[styles.reportItemValue, { color: Colors.text }]}>
              {formatMoney(avg3MonthRemaining)}
            </Text>
            <Text style={[styles.reportItemSub, { color: Colors.textSecondary }]}>
              최근 3개월 기준
            </Text>
          </View>

          {/* 1년 예상 저축 */}
          <View
            style={[
              styles.reportItemWide,
              { backgroundColor: Colors.background, borderColor: '#2ECC7133' },
            ]}
          >
            <View style={styles.reportItemWideLeft}>
              <Ionicons name="rocket-outline" size={22} color="#2ECC71" />
              <View style={{ marginLeft: 12 }}>
                <Text style={[styles.reportItemLabel, { color: Colors.textSecondary }]}>
                  이 추세로 1년 모으면
                </Text>
                <Text style={[styles.reportItemValueLarge, { color: '#2ECC71' }]}>
                  {formatMoney(projectedYearlySavings)}
                </Text>
              </View>
            </View>
            <Ionicons name="sparkles" size={20} color="#FFD93D" />
          </View>
        </View>
      </View>

      {/* ───── 이번 달 사용 내역 ───── */}
      <View style={[styles.txSection, { backgroundColor: Colors.surface }]}>
        <View style={styles.txHeader}>
          <Text style={[styles.txTitle, { color: Colors.text }]}>이번 달 사용 내역</Text>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowAddModal(true)}
            activeOpacity={0.7}
          >
            <Ionicons name="add-circle" size={28} color={Colors.primary || '#6C63FF'} />
          </TouchableOpacity>
        </View>

        {currentMonthPersonalTxs.length === 0 ? (
          <View style={styles.emptyTxContainer}>
            <Ionicons name="receipt-outline" size={48} color={Colors.textSecondary + '44'} />
            <Text style={[styles.emptyTxText, { color: Colors.textSecondary }]}>
              아직 용돈 사용 내역이 없어요
            </Text>
          </View>
        ) : (
          currentMonthPersonalTxs.map((tx) => {
            const catInfo = PERSONAL_CATEGORIES.find((c) => c.key === tx.category) ||
              PERSONAL_CATEGORIES[PERSONAL_CATEGORIES.length - 1];

            return (
              <View key={tx.id} style={[styles.txItem, { borderBottomColor: Colors.background }]}>
                <View style={[styles.txIconCircle, { backgroundColor: catInfo.color + '20' }]}>
                  <Ionicons name={catInfo.icon} size={20} color={catInfo.color} />
                </View>
                <View style={styles.txInfo}>
                  <Text style={[styles.txCategory, { color: Colors.text }]}>{tx.category}</Text>
                  <Text style={[styles.txDesc, { color: Colors.textSecondary }]}>
                    {tx.description} · {tx.date?.slice(5)}
                  </Text>
                </View>
                <Text style={[styles.txAmount, { color: '#FF6B6B' }]}>
                  -{formatMoneyShort(tx.amount)}
                </Text>
              </View>
            );
          })
        )}
      </View>

      <View style={{ height: 40 }} />

      {/* ═════ 지출 추가 모달 ═════ */}
      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: Colors.surface }]}>
            {/* 모달 핸들 */}
            <View style={styles.modalHandle} />

            <Text style={[styles.modalTitle, { color: Colors.text }]}>용돈 사용 추가</Text>

            {/* 카테고리 선택 */}
            <Text style={[styles.modalLabel, { color: Colors.textSecondary }]}>카테고리</Text>
            <View style={styles.categoryGrid}>
              {PERSONAL_CATEGORIES.map((cat) => (
                <TouchableOpacity
                  key={cat.key}
                  style={[
                    styles.categoryItem,
                    {
                      backgroundColor:
                        selectedCategory === cat.key ? cat.color + '20' : Colors.background,
                      borderColor: selectedCategory === cat.key ? cat.color : 'transparent',
                    },
                  ]}
                  onPress={() => setSelectedCategory(cat.key)}
                >
                  <Ionicons
                    name={cat.icon}
                    size={22}
                    color={selectedCategory === cat.key ? cat.color : Colors.textSecondary}
                  />
                  <Text
                    style={[
                      styles.categoryItemText,
                      {
                        color: selectedCategory === cat.key ? cat.color : Colors.textSecondary,
                      },
                    ]}
                  >
                    {cat.key}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* 금액 */}
            <Text style={[styles.modalLabel, { color: Colors.textSecondary }]}>금액</Text>
            <TextInput
              style={[
                styles.modalInput,
                { backgroundColor: Colors.background, color: Colors.text },
              ]}
              placeholder="금액을 입력하세요"
              placeholderTextColor={Colors.textSecondary + '88'}
              keyboardType="number-pad"
              value={expenseAmount}
              onChangeText={setExpenseAmount}
            />

            {/* 메모 */}
            <Text style={[styles.modalLabel, { color: Colors.textSecondary }]}>메모 (선택)</Text>
            <TextInput
              style={[
                styles.modalInput,
                { backgroundColor: Colors.background, color: Colors.text },
              ]}
              placeholder="어디서 사용했나요?"
              placeholderTextColor={Colors.textSecondary + '88'}
              value={expenseDesc}
              onChangeText={setExpenseDesc}
            />

            {/* 버튼 */}
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalBtn, { backgroundColor: Colors.background }]}
                onPress={() => {
                  setShowAddModal(false);
                  setSelectedCategory(null);
                  setExpenseAmount('');
                  setExpenseDesc('');
                }}
              >
                <Text style={[styles.modalBtnText, { color: Colors.textSecondary }]}>취소</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalBtn, styles.modalBtnPrimary]}
                onPress={handleAddExpense}
              >
                <Text style={[styles.modalBtnText, { color: '#fff' }]}>추가</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

// ═════════════════════════════════════════
// 스타일
// ═════════════════════════════════════════
const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingBottom: 30 },

  // ───── 헤더 ─────
  header: {
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 32,
    paddingHorizontal: 24,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    overflow: 'hidden',
  },
  headerDecor1: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: 'rgba(255,255,255,0.08)',
    top: -40,
    right: -40,
  },
  headerDecor2: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.06)',
    bottom: -20,
    left: -20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
  },
  headerMonth: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 2,
    marginBottom: 20,
  },

  // 원형 인디케이터
  circleContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  circleOuter: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  circleProgress: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
    opacity: 0.3,
  },
  circleInner: {
    width: 78,
    height: 78,
    borderRadius: 39,
    backgroundColor: 'rgba(0,0,0,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  circlePercent: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
  },
  circleLabel: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.7)',
    marginTop: -2,
  },

  // 헤더 통계
  headerStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(0,0,0,0.15)',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 8,
  },
  headerStatItem: { alignItems: 'center', flex: 1 },
  headerStatDivider: {
    width: 1,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  headerStatLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.6)',
    marginBottom: 4,
  },
  headerStatValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },

  // ───── 리포트 카드 ─────
  reportCard: {
    margin: 16,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  reportHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  reportTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginLeft: 8,
  },
  reportGrid: {
    gap: 10,
  },
  reportItem: {
    borderRadius: 14,
    padding: 16,
    marginBottom: 4,
  },
  reportItemLabel: {
    fontSize: 12,
    marginTop: 6,
  },
  reportItemValue: {
    fontSize: 20,
    fontWeight: '800',
    marginTop: 2,
  },
  reportItemSub: {
    fontSize: 11,
    marginTop: 2,
  },
  reportItemWide: {
    borderRadius: 14,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
  },
  reportItemWideLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  reportItemValueLarge: {
    fontSize: 22,
    fontWeight: '800',
    marginTop: 2,
  },

  // ───── 거래 내역 ─────
  txSection: {
    marginHorizontal: 16,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  txHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  txTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  addButton: {
    padding: 2,
  },
  emptyTxContainer: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyTxText: {
    marginTop: 12,
    fontSize: 14,
  },
  txItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  txIconCircle: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  txInfo: {
    flex: 1,
    marginLeft: 12,
  },
  txCategory: {
    fontSize: 15,
    fontWeight: '600',
  },
  txDesc: {
    fontSize: 12,
    marginTop: 2,
  },
  txAmount: {
    fontSize: 15,
    fontWeight: '700',
  },

  // ───── 모달 ─────
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    paddingBottom: Platform.OS === 'ios' ? 40 : 24,
  },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#ccc',
    alignSelf: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 20,
  },
  modalLabel: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 12,
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  categoryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1.5,
  },
  categoryItemText: {
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 6,
  },
  modalInput: {
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 24,
  },
  modalBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
  },
  modalBtnPrimary: {
    backgroundColor: '#6C63FF',
  },
  modalBtnText: {
    fontSize: 16,
    fontWeight: '700',
  },

  emptyText: {
    textAlign: 'center',
    marginTop: 100,
    fontSize: 16,
  },
});