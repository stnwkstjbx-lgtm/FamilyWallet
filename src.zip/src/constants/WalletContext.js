/**
 * WalletContext.js
 * ─────────────────────────────────────────────
 * 수정/추가 사항:
 *   - 용돈 배분 시 가족 총 지출에 전액 반영 (allowance_allocation 트랜잭션)
 *   - 개인 용돈 사용내역은 본인만 조회 가능
 *   - 용돈 잔액/통계 조회 함수 추가
 *   - 월별 용돈 배분 기록 관리
 * ─────────────────────────────────────────────
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  deleteField,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  getDocs,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../firebase/firebaseConfig';
import { useAuth } from './AuthContext';

const WalletContext = createContext();
export const useWallet = () => useContext(WalletContext);

const MAX_WALLETS = 3;
export const maxWallets = MAX_WALLETS;

export function WalletProvider({ children }) {
  const { user } = useAuth();

  const [wallets, setWallets] = useState([]);
  const [currentWalletId, setCurrentWalletId] = useState(null);
  const [currentWallet, setCurrentWallet] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  // ══════════════════════════════════════════
  // 기존 가계부 CRUD (생략하지 않고 핵심만 포함)
  // ══════════════════════════════════════════

  // 6자리 초대코드 생성
  const generateInviteCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
  };

  // 가계부 생성
  const createWallet = async (name) => {
    if (!user) throw new Error('로그인이 필요합니다');
    if (wallets.length >= MAX_WALLETS) throw new Error(`최대 ${MAX_WALLETS}개의 가계부만 만들 수 있어요`);

    const inviteCode = generateInviteCode();
    const walletRef = doc(collection(db, 'wallets'));
    const walletData = {
      name,
      inviteCode,
      createdBy: user.uid,
      members: {
        [user.uid]: {
          name: user.displayName || user.email,
          role: 'admin',
          monthlyAllowance: 0,
        },
      },
      fixedExpenses: [],
      createdAt: new Date().toISOString(),
    };

    await setDoc(walletRef, walletData);

    // 유저 문서에 wallet 추가
    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);
    const currentWallets = userSnap.data()?.wallets || [];
    await updateDoc(userRef, { wallets: [...currentWallets, walletRef.id] });

    return walletRef.id;
  };

  // 초대코드로 합류
  const joinWallet = async (inviteCode) => {
    if (!user) throw new Error('로그인이 필요합니다');
    if (wallets.length >= MAX_WALLETS) throw new Error(`최대 ${MAX_WALLETS}개의 가계부만 참여할 수 있어요`);

    const walletsRef = collection(db, 'wallets');
    const q = query(walletsRef, where('inviteCode', '==', inviteCode.toUpperCase()));
    const snap = await getDocs(q);

    if (snap.empty) throw new Error('유효하지 않은 초대코드예요');

    const walletDoc = snap.docs[0];
    const walletData = walletDoc.data();

    if (walletData.members[user.uid]) throw new Error('이미 참여 중인 가계부예요');

    await updateDoc(doc(db, 'wallets', walletDoc.id), {
      [`members.${user.uid}`]: {
        name: user.displayName || user.email,
        role: 'member',
        monthlyAllowance: 0,
      },
    });

    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);
    const currentWallets = userSnap.data()?.wallets || [];
    await updateDoc(userRef, { wallets: [...currentWallets, walletDoc.id] });

    return walletDoc.id;
  };

  // 가계부 전환
  const switchWallet = (walletId) => {
    setCurrentWalletId(walletId);
  };

  // 가계부 나가기
  const leaveWallet = async (walletId) => {
    if (!user) return;
    const walletRef = doc(db, 'wallets', walletId);
    const walletSnap = await getDoc(walletRef);
    if (!walletSnap.exists()) return;

    const data = walletSnap.data();
    const memberIds = Object.keys(data.members);

    if (memberIds.length === 1) {
      // 혼자 → 삭제
      await deleteDoc(walletRef);
    } else if (data.members[user.uid]?.role === 'admin') {
      // 관리자 → 다음 멤버에게 위임
      const nextAdminId = memberIds.find((id) => id !== user.uid);
      await updateDoc(walletRef, {
        [`members.${nextAdminId}.role`]: 'admin',
        [`members.${user.uid}`]: deleteField(),
      });
    } else {
      await updateDoc(walletRef, {
        [`members.${user.uid}`]: deleteField(),
      });
    }

    // 유저 문서에서 제거
    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);
    const currentWallets = (userSnap.data()?.wallets || []).filter((id) => id !== walletId);
    await updateDoc(userRef, { wallets: currentWallets });

    if (currentWalletId === walletId) setCurrentWalletId(null);
  };

  // 가계부 목록으로 이동
  const goToWalletList = () => setCurrentWalletId(null);

  // ══════════════════════════════════════════
  // 트랜잭션 추가
  // ══════════════════════════════════════════

  const addTransaction = async (transactionData) => {
    if (!currentWalletId || !user) return;
    const txRef = collection(db, 'wallets', currentWalletId, 'transactions');
    await addDoc(txRef, {
      ...transactionData,
      memberId: user.uid,
      memberName: user.displayName || user.email,
      createdAt: new Date().toISOString(),
    });
  };

  // ══════════════════════════════════════════
  // ★ 용돈 배분 시스템 (NEW)
  // ══════════════════════════════════════════

  /**
   * 관리자가 멤버에게 용돈을 배분
   * → 가족 총 지출에 전액 지출로 잡힘 (allowance_allocation)
   * → 해당 멤버의 monthlyAllowance 업데이트
   *
   * @param {string} memberId - 배분 대상 멤버 UID
   * @param {number} amount - 월 용돈 금액
   * @param {string} [yearMonth] - 'YYYY-MM' (기본: 현재 월)
   */
  const allocateAllowance = async (memberId, amount, yearMonth) => {
    if (!currentWalletId || !user) return;
    if (!currentWallet?.members[user.uid] || currentWallet.members[user.uid].role !== 'admin') {
      throw new Error('관리자만 용돈을 배분할 수 있어요');
    }

    const now = new Date();
    const ym = yearMonth || `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const memberName = currentWallet.members[memberId]?.name || '멤버';

    // 1) 가계부 멤버 정보에 monthlyAllowance 업데이트
    await updateDoc(doc(db, 'wallets', currentWalletId), {
      [`members.${memberId}.monthlyAllowance`]: amount,
    });

    // 2) 기존 해당 월 용돈 배분 트랜잭션이 있으면 삭제 후 재생성
    //    (같은 달에 중복 배분 방지)
    const txRef = collection(db, 'wallets', currentWalletId, 'transactions');
    const existingQ = query(
      txRef,
      where('fundType', '==', 'allowance_allocation'),
      where('allocatedTo', '==', memberId),
      where('allocMonth', '==', ym)
    );
    const existingSnap = await getDocs(existingQ);
    for (const d of existingSnap.docs) {
      await deleteDoc(d.ref);
    }

    // 3) 가족 총 지출에 반영되는 용돈 배분 트랜잭션 생성
    await addDoc(txRef, {
      type: 'expense',
      fundType: 'allowance_allocation',
      category: '용돈',
      amount,
      description: `${memberName} 용돈 (${ym})`,
      date: `${ym}-01`,
      allocMonth: ym,               // 배분 대상 월
      allocatedTo: memberId,         // 배분 대상 멤버
      allocatedToName: memberName,
      memberId: user.uid,            // 배분한 사람 (관리자)
      memberName: user.displayName || user.email,
      createdAt: new Date().toISOString(),
    });
  };

  /**
   * 용돈에서 개인 지출 추가
   * → 가족 총 지출에는 안 잡힘 (이미 allowance_allocation으로 전액 잡혀 있으므로)
   * → 본인만 조회 가능한 개인 지출
   */
  const addPersonalExpense = async ({ category, amount, description, date }) => {
    if (!currentWalletId || !user) return;

    const txRef = collection(db, 'wallets', currentWalletId, 'transactions');
    await addDoc(txRef, {
      type: 'expense',
      fundType: 'personal',
      category,
      amount,
      description,
      date: date || new Date().toISOString().slice(0, 10),
      memberId: user.uid,
      memberName: user.displayName || user.email,
      createdAt: new Date().toISOString(),
    });
  };

  // ══════════════════════════════════════════
  // ★ 용돈 조회 함수들 (NEW)
  // ══════════════════════════════════════════

  /**
   * 특정 월의 내 용돈 배분액 조회
   */
  const getMyAllowanceForMonth = useCallback(
    (yearMonth) => {
      if (!user) return 0;
      const allocation = transactions.find(
        (tx) =>
          tx.fundType === 'allowance_allocation' &&
          tx.allocatedTo === user.uid &&
          tx.allocMonth === yearMonth
      );
      return allocation?.amount || 0;
    },
    [transactions, user]
  );

  /**
   * 특정 월의 내 용돈 사용액 조회
   */
  const getMyPersonalSpendingForMonth = useCallback(
    (yearMonth) => {
      if (!user) return 0;
      return transactions
        .filter((tx) => {
          if (tx.fundType !== 'personal' || tx.memberId !== user.uid) return false;
          const txMonth = tx.date?.slice(0, 7);
          return txMonth === yearMonth;
        })
        .reduce((sum, tx) => sum + (tx.amount || 0), 0);
    },
    [transactions, user]
  );

  /**
   * 특정 월의 내 용돈 잔액
   */
  const getMyAllowanceRemaining = useCallback(
    (yearMonth) => {
      const allocated = getMyAllowanceForMonth(yearMonth);
      const spent = getMyPersonalSpendingForMonth(yearMonth);
      return allocated - spent;
    },
    [getMyAllowanceForMonth, getMyPersonalSpendingForMonth]
  );

  /**
   * ★ 용돈 통계 리포트
   * - 이번 달 배분/사용/잔액
   * - 저번 달 잔액
   * - 최근 3개월 평균 잔액
   * - 이 추세로 1년 모으면 예상 저축액
   */
  const getAllowanceReport = useCallback(() => {
    if (!user) return null;

    const now = new Date();
    const months = [];

    // 최근 6개월 데이터 (충분한 히스토리)
    for (let i = 0; i < 6; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
    }

    const currentMonth = months[0];
    const lastMonth = months[1];

    // 이번 달
    const currentAllocation = getMyAllowanceForMonth(currentMonth);
    const currentSpending = getMyPersonalSpendingForMonth(currentMonth);
    const currentRemaining = currentAllocation - currentSpending;

    // 저번 달
    const lastAllocation = getMyAllowanceForMonth(lastMonth);
    const lastSpending = getMyPersonalSpendingForMonth(lastMonth);
    const lastRemaining = lastAllocation - lastSpending;

    // 최근 3개월 (저번 달 포함, 이번 달 제외 — 진행 중이므로)
    const recentMonths = months.slice(1, 4); // 지난 1~3개월
    let totalRemaining = 0;
    let validMonthCount = 0;

    recentMonths.forEach((ym) => {
      const alloc = getMyAllowanceForMonth(ym);
      if (alloc > 0) {
        // 배분이 있었던 달만 계산
        const spent = getMyPersonalSpendingForMonth(ym);
        totalRemaining += alloc - spent;
        validMonthCount++;
      }
    });

    const avg3MonthRemaining = validMonthCount > 0 ? Math.round(totalRemaining / validMonthCount) : 0;

    // 1년 예상 저축 (3개월 평균 잔액 × 12)
    const projectedYearlySavings = avg3MonthRemaining * 12;

    // 이번 달 개인 지출 내역 (본인 것만)
    const currentMonthPersonalTxs = transactions.filter(
      (tx) =>
        tx.fundType === 'personal' &&
        tx.memberId === user.uid &&
        tx.date?.slice(0, 7) === currentMonth
    );

    return {
      currentMonth,
      lastMonth,
      current: {
        allocation: currentAllocation,
        spending: currentSpending,
        remaining: currentRemaining,
      },
      last: {
        allocation: lastAllocation,
        spending: lastSpending,
        remaining: lastRemaining,
      },
      avg3MonthRemaining,
      projectedYearlySavings,
      currentMonthPersonalTxs,
    };
  }, [user, transactions, getMyAllowanceForMonth, getMyPersonalSpendingForMonth]);

  /**
   * 가족 전체 지출 계산 (공금 + 용돈배분)
   * → personal(개인 용돈 사용)은 제외 (이미 allowance_allocation으로 잡혀있으므로)
   */
  const getFamilyTotalExpense = useCallback(
    (yearMonth) => {
      return transactions
        .filter((tx) => {
          if (tx.type !== 'expense') return false;
          // personal(용돈 사용 내역)은 가족 총 지출에서 제외
          // shared(공금) + allowance_allocation(용돈 배분) 만 합산
          if (tx.fundType === 'personal') return false;
          const txMonth = tx.date?.slice(0, 7);
          return txMonth === yearMonth;
        })
        .reduce((sum, tx) => sum + (tx.amount || 0), 0);
    },
    [transactions]
  );

  /**
   * 가족 전체 수입 계산
   */
  const getFamilyTotalIncome = useCallback(
    (yearMonth) => {
      return transactions
        .filter((tx) => {
          if (tx.type !== 'income') return false;
          const txMonth = tx.date?.slice(0, 7);
          return txMonth === yearMonth;
        })
        .reduce((sum, tx) => sum + (tx.amount || 0), 0);
    },
    [transactions]
  );

  // ══════════════════════════════════════════
  // Firestore 리스너
  // ══════════════════════════════════════════

  // 유저의 가계부 목록 리스너
  useEffect(() => {
    if (!user) {
      setWallets([]);
      setCurrentWalletId(null);
      setLoading(false);
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    const unsub = onSnapshot(userRef, async (snap) => {
      const walletIds = snap.data()?.wallets || [];
      const walletList = [];

      for (const wid of walletIds) {
        const wSnap = await getDoc(doc(db, 'wallets', wid));
        if (wSnap.exists()) {
          walletList.push({ id: wSnap.id, ...wSnap.data() });
        }
      }

      setWallets(walletList);
      setLoading(false);
    });

    return () => unsub();
  }, [user]);

  // 현재 가계부 리스너
  useEffect(() => {
    if (!currentWalletId) {
      setCurrentWallet(null);
      return;
    }

    const unsub = onSnapshot(doc(db, 'wallets', currentWalletId), (snap) => {
      if (snap.exists()) {
        setCurrentWallet({ id: snap.id, ...snap.data() });
      }
    });

    return () => unsub();
  }, [currentWalletId]);

  // 트랜잭션 리스너
  useEffect(() => {
    if (!currentWalletId) {
      setTransactions([]);
      return;
    }

    const txRef = collection(db, 'wallets', currentWalletId, 'transactions');
    const q = query(txRef, orderBy('date', 'desc'));

    const unsub = onSnapshot(q, (snap) => {
      const txList = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setTransactions(txList);
    });

    return () => unsub();
  }, [currentWalletId]);

  // ══════════════════════════════════════════
  // Context Value
  // ══════════════════════════════════════════

  const value = {
    // 기존
    wallets,
    currentWalletId,
    currentWallet,
    transactions,
    loading,
    createWallet,
    joinWallet,
    switchWallet,
    leaveWallet,
    goToWalletList,
    addTransaction,

    // ★ 용돈 시스템 (NEW)
    allocateAllowance,
    addPersonalExpense,
    getMyAllowanceForMonth,
    getMyPersonalSpendingForMonth,
    getMyAllowanceRemaining,
    getAllowanceReport,
    getFamilyTotalExpense,
    getFamilyTotalIncome,
  };

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}